<?php
// templates/frontend/index.php - Frontend Template

// Get all content
$siteName = siteName();
$siteTagline = siteTagline();
$siteDescription = siteDescription();
$logo = getSetting('logo', '');
$favicon = getSetting('favicon', '');
$footerText = getSetting('footer_text', '');
$contactEmail = siteEmail();
$contactPhone = sitePhone();
$contactAddress = siteAddress();

// Content blocks
$heroTitle = getContentBlock('hero_title');
$heroSubtitle = getContentBlock('hero_subtitle');
$heroBadge = getContentBlock('hero_badge');
$aboutTitle = getContentBlock('about_title');
$aboutSubtitle = getContentBlock('about_subtitle');
$aboutContent = getContentBlock('about_content');

// Dynamic data
$services = getServices();
$portfolio = getPortfolio();
$testimonials = getTestimonials();
$faqs = getFaqs();
$statistics = getStatistics();
$socialLinks = getSocialLinks();
$menuItems = getMenu('main');

// SEO
$seo = getSeo('home');

// Success/Error messages
$success = $_SESSION['contact_success'] ?? '';
$error = $_SESSION['contact_error'] ?? '';
unset($_SESSION['contact_success'], $_SESSION['contact_error']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?= $seo ? $seo['title'] : ($siteName . ' — ' . $siteTagline) ?></title>
    <meta name="description" content="<?= $seo ? $seo['description'] : $siteDescription ?>" />
    <?php if ($seo && $seo['keywords']): ?>
    <meta name="keywords" content="<?= $seo['keywords'] ?>" />
    <?php endif; ?>
    <?php if ($seo && $seo['canonical']): ?>
    <link rel="canonical" href="<?= $seo['canonical'] ?>" />
    <?php endif; ?>
    <?php if ($favicon): ?>
    <link rel="icon" href="<?= SITE_URL ?>uploads/<?= $favicon ?>" />
    <?php endif; ?>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,400;14..32,500;14..32,600;14..32,700&family=Poppins:wght@600;700;800;900&display=swap"
        rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
    <style>
        /* YOUR ORIGINAL CSS HERE - Copy from your index.html */
        /* Note: All styles from your original index.html should be placed here */
        
        /* Quick example - you should copy your complete CSS from the original file */
        :root {
            --primary: #E61A27;
            --primary-dark: #C4101B;
            --primary-light: #FF4D5A;
            --primary-gradient: linear-gradient(135deg, #E61A27 0%, #C4101B 100%);
            --secondary-dark: #0A0A0A;
            --secondary-light: #1A1A1A;
            --text-primary: #0A0A0A;
            --text-secondary: #4A4A4A;
            --text-light: #FFFFFF;
            --bg-light: #F6F7F9;
            --bg-white: #FFFFFF;
            --shadow-sm: 0 4px 20px rgba(0, 0, 0, 0.04);
            --shadow-md: 0 8px 40px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 20px 80px rgba(0, 0, 0, 0.12);
            --shadow-xl: 0 40px 120px rgba(0, 0, 0, 0.18);
            --radius-sm: 8px;
            --radius-md: 16px;
            --radius-lg: 24px;
            --radius-xl: 32px;
            --transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            --transition-slow: all 0.6s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            --max-width: 1280px;
            --section-padding: 100px 0;
            --glass-bg: rgba(255, 255, 255, 0.75);
            --glass-border: rgba(255, 255, 255, 0.2);
        }
        
        /* ... COPY ALL YOUR CSS FROM index.html HERE ... */
        
        /* Alert messages */
        .alert-custom {
            padding: 16px 24px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .alert-custom.success {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.2);
            color: #10b981;
        }
        .alert-custom.error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.2);
            color: #ef4444;
        }
    </style>
</head>

<body>

    <!-- ===== SCROLL PROGRESS ===== -->
    <div id="scrollProgress"></div>

    <!-- ===== ALERT MESSAGES ===== -->
    <?php if ($success): ?>
        <div class="container" style="padding-top:100px;">
            <div class="alert-custom success"><i class="fas fa-check-circle me-2"></i> <?= htmlspecialchars($success) ?></div>
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="container" style="padding-top:100px;">
            <div class="alert-custom error"><i class="fas fa-exclamation-circle me-2"></i> <?= htmlspecialchars($error) ?></div>
        </div>
    <?php endif; ?>

    <!-- ===== NAVIGATION ===== -->
    <nav class="navbar" id="navbar" role="navigation" aria-label="Main Navigation">
        <div class="container">
            <a href="#" class="logo" aria-label="<?= siteName() ?> Home"><?= siteName() ?><span>.</span></a>
            <ul class="nav-links" id="navLinks" role="menubar">
                <?php foreach ($menuItems as $item): ?>
                    <?php if (empty($item['children'])): ?>
                        <li role="none"><a href="<?= $item['url'] ?>" role="menuitem" <?= $item['target'] ? 'target="' . $item['target'] . '"' : '' ?>><?= $item['label'] ?></a></li>
                    <?php else: ?>
                        <li role="none" class="dropdown">
                            <a href="#" role="menuitem"><?= $item['label'] ?></a>
                            <ul>
                                <?php foreach ($item['children'] as $child): ?>
                                    <li><a href="<?= $child['url'] ?>" <?= $child['target'] ? 'target="' . $child['target'] . '"' : '' ?>><?= $child['label'] ?></a></li>
                                <?php endforeach; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                <?php endforeach; ?>
                <li role="none"><a href="#contact" class="btn-nav" role="menuitem">Get a Quote</a></li>
            </ul>
            <div class="menu-toggle" id="menuToggle" aria-label="Toggle Menu" role="button" tabindex="0">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- ===== HERO ===== -->
    <section class="hero" id="hero" aria-label="Hero Section">
        <div class="container">
            <div class="hero-content" data-aos="fade-right" data-aos-duration="800">
                <span class="section-badge"
                    style="background:rgba(230,26,39,0.15);color:#fff;border-color:rgba(255,255,255,0.08);"><?= $heroBadge ? $heroBadge['content'] : '7 Years of Excellence' ?></span>
                <h1>
                    <?php
                    $title = $heroTitle ? $heroTitle['content'] : 'Making a Massive Impact Since 2017';
                    $parts = explode('Massive Impact', $title);
                    if (count($parts) > 1) {
                        echo $parts[0] . '<span class="highlight">Massive Impact<span class="underline"></span></span>' . $parts[1];
                    } else {
                        echo $title;
                    }
                    ?>
                </h1>
                <p><?= $heroSubtitle ? $heroSubtitle['content'] : 'India\'s premier full-service advertising agency — delivering Offline, Transit, Digital, and Non-Traditional media solutions that create lasting impressions and measurable results.' ?></p>
                <div class="hero-buttons">
                    <a href="#services" class="btn-primary"><span>Explore Our Work</span> <i class="fas fa-arrow-right"></i></a>
                    <a href="#contact" class="btn-outline">Get a Quote</a>
                </div>
                <div class="hero-trust">
                    <span class="trust-item"><i class="fas fa-check-circle"></i> 7+ Years of Excellence</span>
                    <span class="trust-item"><i class="fas fa-check-circle"></i> Full-Service Agency</span>
                    <span class="trust-item"><i class="fas fa-check-circle"></i> Pan-India Presence</span>
                </div>
            </div>
            <div class="hero-visual" data-aos="fade-left" data-aos-duration="800" data-aos-delay="200">
                <img src="<?= SITE_URL ?>uploads/images/hero_visual.jpg" alt="Marketing & Advertising campaigns" class="hero-main-img" />
                <div class="floating-grid">
                    <div class="floating-item">
                        <img src="<?= SITE_URL ?>uploads/images/portfolio_hoarding.png" alt="Hoardings" class="floating-thumb" />
                        <span>Hoardings</span>
                    </div>
                    <div class="floating-item">
                        <img src="<?= SITE_URL ?>uploads/images/portfolio_bus.png" alt="Transit" class="floating-thumb" />
                        <span>Transit</span>
                    </div>
                    <div class="floating-item">
                        <img src="<?= SITE_URL ?>uploads/images/portfolio_airport.png" alt="Airport" class="floating-thumb" />
                        <span>Airport</span>
                    </div>
                    <div class="floating-item">
                        <img src="<?= SITE_URL ?>uploads/images/portfolio_metro.png" alt="Metro" class="floating-thumb" />
                        <span>Metro</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== CLIENTS MARQUEE ===== -->
    <section class="clients" id="clients" aria-label="Our Clients">
        <div class="container">
            <div class="clients-marquee">
                <span class="client-item"><i class="fas fa-building"></i> Tata Group</span>
                <span class="client-item"><i class="fas fa-building"></i> Reliance</span>
                <span class="client-item"><i class="fas fa-signal"></i> Airtel</span>
                <span class="client-item"><i class="fas fa-wifi"></i> Jio</span>
                <span class="client-item"><i class="fas fa-utensils"></i> Zomato</span>
                <span class="client-item"><i class="fas fa-cow"></i> Amul</span>
                <span class="client-item"><i class="fas fa-car"></i> Maruti Suzuki</span>
                <span class="client-item"><i class="fas fa-mobile-alt"></i> Paytm</span>
                <span class="client-item"><i class="fas fa-university"></i> HDFC Bank</span>
                <span class="client-item"><i class="fas fa-laptop"></i> Infosys</span>
                <!-- Duplicate for seamless loop -->
                <span class="client-item"><i class="fas fa-building"></i> Tata Group</span>
                <span class="client-item"><i class="fas fa-building"></i> Reliance</span>
                <span class="client-item"><i class="fas fa-signal"></i> Airtel</span>
                <span class="client-item"><i class="fas fa-wifi"></i> Jio</span>
                <span class="client-item"><i class="fas fa-utensils"></i> Zomato</span>
                <span class="client-item"><i class="fas fa-cow"></i> Amul</span>
                <span class="client-item"><i class="fas fa-car"></i> Maruti Suzuki</span>
                <span class="client-item"><i class="fas fa-mobile-alt"></i> Paytm</span>
                <span class="client-item"><i class="fas fa-university"></i> HDFC Bank</span>
                <span class="client-item"><i class="fas fa-laptop"></i> Infosys</span>
            </div>
        </div>
    </section>

    <!-- ===== ABOUT ===== -->
    <section class="about" id="about" aria-label="About Us">
        <div class="container">
            <div class="about-grid">
                <div class="about-image" data-aos="fade-right" data-aos-duration="800">
                    <div class="image-wrapper">
                        <img src="<?= SITE_URL ?>uploads/images/about_team.png" alt="Pipani Advertising Creative Team" loading="lazy" />
                    </div>
                    <div class="exp-badge">
                        <div class="number">7+</div>
                        <div class="label">Years of Impact</div>
                    </div>
                </div>
                <div class="about-content" data-aos="fade-left" data-aos-duration="800" data-aos-delay="100">
                    <span class="section-badge">About Us</span>
                    <h2 class="section-title">Who We <span class="highlight">Are</span></h2>
                    <p class="about-tagline"><?= $aboutSubtitle ? $aboutSubtitle['content'] : 'Advertising · PR · Massive Impact' ?></p>
                    <?php if ($aboutContent): ?>
                        <?= $aboutContent['content'] ?>
                    <?php else: ?>
                        <p>For over 7 years, Pipani Advertising has been at the forefront of the advertising industry, helping brands achieve massive impact. As a part of the PIPANI ADVERTISING Group and operating through Adnest Communications LLP, we are a full-service powerhouse specializing in a diverse range of media.</p>
                        <p>From traditional outdoor and transit advertising to innovative digital and non-traditional solutions, our mission is to deliver unparalleled visibility and brand awareness across every touchpoint.</p>
                    <?php endif; ?>
                    <ul class="about-features">
                        <li><i class="fas fa-check-circle"></i> 7+ Years of Excellence</li>
                        <li><i class="fas fa-check-circle"></i> Full-Service Agency</li>
                        <li><i class="fas fa-check-circle"></i> Pan-India Presence</li>
                        <li><i class="fas fa-check-circle"></i> 9 Service Categories</li>
                    </ul>
                    <div class="about-timeline">
                        <div class="milestone">
                            <div class="year">2017</div>
                            <div class="desc">Founded</div>
                        </div>
                        <div class="milestone">
                            <div class="year">2020</div>
                            <div class="desc">Expanded Pan-India</div>
                        </div>
                        <div class="milestone">
                            <div class="year">2024</div>
                            <div class="desc">9 Service Verticals</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== SERVICES ===== -->
    <section class="services" id="services" aria-label="Our Services">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge">What We Do</span>
                <h2 class="section-title">Our <span class="highlight">Services</span></h2>
                <p class="section-subtitle mx-auto">Comprehensive advertising solutions across all media channels to maximize your brand's reach and impact.</p>
            </div>
            <div class="services-grid" data-aos="fade-up" data-aos-delay="100">
                <?php foreach ($services as $service): ?>
                    <div class="service-card">
                        <div class="icon"><i class="<?= $service['icon'] ?>"></i></div>
                        <h3><?= htmlspecialchars($service['title']) ?></h3>
                        <p><?= htmlspecialchars($service['description']) ?></p>
                        <?php if ($service['benefits']): ?>
                            <?php $benefits = json_decode($service['benefits'], true); ?>
                            <?php if ($benefits): ?>
                                <div class="benefits">
                                    <?php foreach ($benefits as $benefit): ?>
                                        <span><?= htmlspecialchars($benefit) ?></span>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <a href="#" class="learn-more">Learn More <i class="fas fa-arrow-right"></i></a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ===== PORTFOLIO ===== -->
    <section class="portfolio" id="portfolio" aria-label="Portfolio">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge">Our Work</span>
                <h2 class="section-title">Campaign <span class="highlight">Showcase</span></h2>
                <p class="section-subtitle mx-auto">Real-world advertising campaigns that delivered massive impact for our clients.</p>
            </div>
            <div class="portfolio-grid" data-aos="fade-up" data-aos-delay="100">
                <?php foreach ($portfolio as $item): ?>
                    <div class="portfolio-item">
                        <img src="<?= SITE_URL ?>uploads/images/<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['title']) ?>" loading="lazy" />
                        <div class="overlay">
                            <span class="tag"><?= htmlspecialchars($item['category'] ?? 'Campaign') ?></span>
                            <h4><?= htmlspecialchars($item['title']) ?></h4>
                            <p><?= htmlspecialchars($item['description']) ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ===== INDUSTRIES ===== -->
    <section class="industries" id="industries" aria-label="Industries We Serve">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge">Industries</span>
                <h2 class="section-title">Sectors We <span class="highlight">Serve</span></h2>
                <p class="section-subtitle mx-auto">Expert advertising solutions tailored to your industry's unique needs.</p>
            </div>
            <div class="industries-grid" data-aos="fade-up" data-aos-delay="100">
                <div class="industry-item"><i class="fas fa-building"></i><span>Real Estate</span></div>
                <div class="industry-item"><i class="fas fa-heart-pulse"></i><span>Healthcare</span></div>
                <div class="industry-item"><i class="fas fa-graduation-cap"></i><span>Education</span></div>
                <div class="industry-item"><i class="fas fa-cart-shopping"></i><span>Retail</span></div>
                <div class="industry-item"><i class="fas fa-car"></i><span>Automobile</span></div>
                <div class="industry-item"><i class="fas fa-utensils"></i><span>Hospitality</span></div>
                <div class="industry-item"><i class="fas fa-landmark"></i><span>Government</span></div>
                <div class="industry-item"><i class="fas fa-vote-yea"></i><span>Political</span></div>
                <div class="industry-item"><i class="fas fa-box-open"></i><span>FMCG</span></div>
            </div>
        </div>
    </section>

    <!-- ===== STATISTICS ===== -->
    <section class="statistics" id="statistics" aria-label="Our Impact in Numbers">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge" style="background:rgba(230,26,39,0.15);color:#fff;border-color:rgba(255,255,255,0.08);">Our Impact</span>
                <h2 class="section-title" style="color:var(--text-light);">By the <span class="highlight">Numbers</span></h2>
                <p class="section-subtitle mx-auto" style="color:rgba(255,255,255,0.5);">Measurable results that speak for themselves.</p>
            </div>
            <div class="stats-grid" data-aos="fade-up" data-aos-delay="100">
                <?php foreach ($statistics as $stat): ?>
                    <div class="stat-item">
                        <div class="number"><span class="counter" data-target="<?= preg_replace('/[^0-9]/', '', $stat['value']) ?>">0</span><span class="suffix"><?= $stat['suffix'] ?></span></div>
                        <div class="label"><?= htmlspecialchars($stat['label']) ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ===== PROCESS ===== -->
    <section class="process" id="process" aria-label="Our Process">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge">Our Process</span>
                <h2 class="section-title">How We <span class="highlight">Work</span></h2>
                <p class="section-subtitle mx-auto">A streamlined approach to deliver exceptional advertising solutions for your brand.</p>
            </div>
            <div class="process-timeline" data-aos="fade-up" data-aos-delay="100">
                <div class="process-step">
                    <div class="step-number">1</div>
                    <h4>Discovery</h4>
                    <p>Understanding your brand, goals, and target audience</p>
                </div>
                <div class="process-step">
                    <div class="step-number">2</div>
                    <h4>Strategy</h4>
                    <p>Developing a tailored media plan for maximum impact</p>
                </div>
                <div class="process-step">
                    <div class="step-number">3</div>
                    <h4>Execution</h4>
                    <p>Flawless implementation across chosen media channels</p>
                </div>
                <div class="process-step">
                    <div class="step-number">4</div>
                    <h4>Analysis</h4>
                    <p>Measuring results and optimizing for continued success</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== WHY CHOOSE US ===== -->
    <section class="why" id="why" aria-label="Why Choose Us">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge">Why Pipani</span>
                <h2 class="section-title">Why Choose <span class="highlight">Us</span></h2>
                <p class="section-subtitle mx-auto">We deliver measurable results through strategic advertising solutions that create massive impact.</p>
            </div>
            <div class="why-grid" data-aos="fade-up" data-aos-delay="100">
                <div class="why-item">
                    <div class="icon"><i class="fas fa-eye"></i></div>
                    <h4>71% Read Rate</h4>
                    <p>71% of people read hoardings carefully while driving</p>
                </div>
                <div class="why-item">
                    <div class="icon"><i class="fas fa-chart-line"></i></div>
                    <h4>80% Response</h4>
                    <p>80% of consumers react to bus ads by purchasing</p>
                </div>
                <div class="why-item">
                    <div class="icon"><i class="fas fa-rocket"></i></div>
                    <h4>50%+ Growth</h4>
                    <p>50%+ increase in purchase via OTT ads in Q2 2020</p>
                </div>
                <div class="why-item">
                    <div class="icon"><i class="fas fa-clock"></i></div>
                    <h4>24/7 Visibility</h4>
                    <p>Round-the-clock visibility through cab and transit advertising</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== TESTIMONIALS ===== -->
    <section class="testimonials" id="testimonials" aria-label="Testimonials">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge">Testimonials</span>
                <h2 class="section-title">What Our <span class="highlight">Clients Say</span></h2>
                <p class="section-subtitle mx-auto">Real feedback from real clients who have experienced massive impact.</p>
            </div>
            <div class="testimonials-grid" data-aos="fade-up" data-aos-delay="100">
                <?php foreach ($testimonials as $testimonial): ?>
                    <div class="testimonial-card">
                        <div class="stars">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <i class="fas fa-star <?= $i <= $testimonial['rating'] ? '' : 'text-muted' ?>"></i>
                            <?php endfor; ?>
                        </div>
                        <p class="quote"><?= htmlspecialchars($testimonial['content']) ?></p>
                        <div class="author">
                            <div class="avatar"><?= substr($testimonial['name'], 0, 2) ?></div>
                            <div class="info">
                                <div class="name"><?= htmlspecialchars($testimonial['name']) ?></div>
                                <div class="company"><?= htmlspecialchars($testimonial['company']) ?>, <?= htmlspecialchars($testimonial['position']) ?></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ===== FAQ ===== -->
    <section class="faq" id="faq" aria-label="Frequently Asked Questions">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge">FAQs</span>
                <h2 class="section-title">Frequently Asked <span class="highlight">Questions</span></h2>
                <p class="section-subtitle mx-auto">Find answers to the most common questions about our services.</p>
            </div>
            <div class="faq-list" data-aos="fade-up" data-aos-delay="100">
                <?php $first = true; foreach ($faqs as $faq): ?>
                    <div class="faq-item <?= $first ? 'active' : '' ?>">
                        <div class="question"><span><?= htmlspecialchars($faq['question']) ?></span> <i class="fas fa-chevron-down"></i></div>
                        <div class="answer"><?= htmlspecialchars($faq['answer']) ?></div>
                    </div>
                    <?php $first = false; endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ===== CONTACT ===== -->
    <section class="contact" id="contact" aria-label="Contact Us">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge">Get In Touch</span>
                <h2 class="section-title">Let's Create <span class="highlight">Massive Impact</span></h2>
                <p class="section-subtitle mx-auto">Ready to elevate your brand? Reach out to our team today.</p>
            </div>
            <div class="contact-cards-grid" data-aos="fade-up" data-aos-delay="100">
                <div class="contact-card">
                    <div class="card-icon"><i class="fas fa-user-tie"></i></div>
                    <h3>Yasin Jamadar</h3>
                    <p class="role">Co-Founder</p>
                    <a href="tel:+919766840787" class="contact-link"><i class="fas fa-phone"></i> +91 9766840787</a>
                    <a href="mailto:yasin@pipaniadvertising.com" class="contact-link"><i class="fas fa-envelope"></i> yasin@pipaniadvertising.com</a>
                    <span class="badge-mini">Management</span>
                </div>
                <div class="contact-card">
                    <div class="card-icon"><i class="fas fa-user-tie"></i></div>
                    <h3>Iqbal Shaikh</h3>
                    <p class="role">Co-Founder</p>
                    <a href="tel:+919511244940" class="contact-link"><i class="fas fa-phone"></i> +91 9511244940</a>
                    <a href="mailto:info.adnestcommunication@gmail.com" class="contact-link"><i class="fas fa-envelope"></i> info.adnestcommunication@gmail.com</a>
                    <span class="badge-mini">Management</span>
                </div>
                <div class="contact-card">
                    <div class="card-icon"><i class="fas fa-building"></i></div>
                    <h3>Adnest Communications</h3>
                    <p class="role">LLP - PIPANI Group</p>
                    <p class="desc"><?= $contactAddress ?></p>
                    <span class="badge-mini">Corporate Office</span>
                </div>
            </div>

            <div class="contact-main-grid" data-aos="fade-up" data-aos-delay="200">
                <form class="contact-form" action="<?= SITE_URL ?>contact.php" method="POST">
                    <h3 class="form-title">Send a Message</h3>
                    <div class="form-row">
                        <input type="text" name="name" placeholder="Your Name" required />
                        <input type="email" name="email" placeholder="Your Email" required />
                    </div>
                    <input type="tel" name="phone" placeholder="Phone Number" />
                    <textarea name="message" placeholder="Tell us about your advertising needs..." required></textarea>
                    <button type="submit" class="btn-primary" style="width:100%;justify-content:center;">
                        <span>Send Message</span> <i class="fas fa-arrow-right"></i>
                    </button>
                </form>
                <div class="contact-map-wrapper">
                    <iframe
                        src="https://maps.google.com/maps?q=Pipani%20Advertising%20Dhankawadi%20Pune&t=&z=15&ie=UTF8&iwloc=&output=embed"
                        allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" id="footer" role="contentinfo">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <a href="#" class="logo"><?= siteName() ?><span>.</span></a>
                    <p>7 Years of making a Massive Impact. India's premier full-service advertising agency delivering measurable results across all media channels.</p>
                    <div class="socials">
                        <?php foreach ($socialLinks as $social): ?>
                            <a href="<?= htmlspecialchars($social['url']) ?>" aria-label="<?= htmlspecialchars($social['platform']) ?>"><i class="fab fa-<?= strtolower(htmlspecialchars($social['platform'])) ?>"></i></a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div>
                    <h4>Services</h4>
                    <ul>
                        <li><a href="#services">Offline Media</a></li>
                        <li><a href="#services">Transit Media</a></li>
                        <li><a href="#services">Electronic Media</a></li>
                        <li><a href="#services">Corporate Gifting</a></li>
                    </ul>
                </div>
                <div>
                    <h4>Industries</h4>
                    <ul>
                        <li><a href="#industries">Real Estate</a></li>
                        <li><a href="#industries">Healthcare</a></li>
                        <li><a href="#industries">Education</a></li>
                        <li><a href="#industries">Retail</a></li>
                    </ul>
                </div>
                <div>
                    <h4>Company</h4>
                    <ul>
                        <li><a href="#about">About Us</a></li>
                        <li><a href="#portfolio">Portfolio</a></li>
                        <li><a href="#clients">Our Clients</a></li>
                        <li><a href="#contact">Contact</a></li>
                    </ul>
                </div>
                <div>
                    <h4>Newsletter</h4>
                    <p style="font-size:0.85rem;color:rgba(255,255,255,0.4);margin-bottom:12px;">Get the latest updates on campaigns and advertising trends.</p>
                    <div class="footer-newsletter">
                        <input type="email" placeholder="Your Email" />
                        <button type="button">Subscribe</button>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <span>&copy; <?= $footerText ?: '2026 Pipani Advertising. A Part of the PIPANI ADVERTISING Group. All Rights Reserved.' ?></span>
                <div class="links">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms</a>
                    <a href="#contact">Contact</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- ===== BACK TO TOP ===== -->
    <button class="back-to-top" id="backToTop" aria-label="Back to Top">
        <i class="fas fa-arrow-up"></i>
    </button>

    <!-- ===== SCRIPTS ===== -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        // ===== AOS INIT =====
        AOS.init({
            duration: 700,
            once: true,
            offset: 40,
            easing: 'ease-out-cubic'
        });

        // ===== SCROLL PROGRESS =====
        const scrollProgress = document.getElementById('scrollProgress');
        window.addEventListener('scroll', () => {
            const scrollTop = window.scrollY;
            const docHeight = document.documentElement.scrollHeight - window.innerHeight;
            const progress = (scrollTop / docHeight) * 100;
            scrollProgress.style.width = progress + '%';
        });

        // ===== NAVBAR =====
        const navbar = document.getElementById('navbar');
        const navLinks = document.getElementById('navLinks');
        const menuToggle = document.getElementById('menuToggle');

        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // ===== MOBILE MENU =====
        menuToggle.addEventListener('click', () => {
            menuToggle.classList.toggle('active');
            navLinks.classList.toggle('active');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                menuToggle.classList.remove('active');
                navLinks.classList.remove('active');
            });
        });

        // ===== BACK TO TOP =====
        const backToTop = document.getElementById('backToTop');
        window.addEventListener('scroll', () => {
            if (window.scrollY > 400) {
                backToTop.classList.add('visible');
            } else {
                backToTop.classList.remove('visible');
            }
        });
        backToTop.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });

        // ===== COUNTER ANIMATION =====
        const counters = document.querySelectorAll('.counter');
        let counted = false;

        const counterObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !counted) {
                    counted = true;
                    counters.forEach(counter => {
                        const target = parseInt(counter.getAttribute('data-target'));
                        const duration = 2000;
                        const startTime = performance.now();

                        function updateCounter(currentTime) {
                            const elapsed = currentTime - startTime;
                            const progress = Math.min(elapsed / duration, 1);
                            const value = Math.floor(progress * target);
                            counter.textContent = value;
                            if (progress < 1) {
                                requestAnimationFrame(updateCounter);
                            } else {
                                counter.textContent = target;
                            }
                        }
                        requestAnimationFrame(updateCounter);
                    });
                }
            });
        }, { threshold: 0.3 });

        counters.forEach(c => counterObserver.observe(c));

        // ===== FAQ ACCORDION =====
        const faqItems = document.querySelectorAll('.faq-item');
        faqItems.forEach(item => {
            item.addEventListener('click', () => {
                const isActive = item.classList.contains('active');
                faqItems.forEach(i => i.classList.remove('active'));
                if (!isActive) item.classList.add('active');
            });
        });
    </script>
</body>
</html>