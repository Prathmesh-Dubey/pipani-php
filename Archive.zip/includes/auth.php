<?php
// includes/auth.php

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/functions.php';

class Auth {
    public static function login($username, $password, $remember = false) {
        try {
            $stmt = db()->prepare("SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                if ($user['status'] != 1) {
                    return ['success' => false, 'error' => 'Account is disabled'];
                }

                // Update last login
                $stmt = db()->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                $stmt->execute([$user['id']]);

                // Set session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['logged_in'] = true;

                // Remember me
                if ($remember) {
                    $token = bin2hex(random_bytes(32));
                    $stmt = db()->prepare("UPDATE users SET remember_token = ? WHERE id = ?");
                    $stmt->execute([$token, $user['id']]);
                    setcookie('remember_token', $token, time() + 86400 * 30, '/');
                }

                logActivity($user['id'], 'login', 'User logged in');

                return ['success' => true, 'user' => $user];
            }

            return ['success' => false, 'error' => 'Invalid username or password'];
        } catch (PDOException $e) {
            return ['success' => false, 'error' => 'Database error'];
        }
    }

    public static function checkRememberMe() {
        if (isset($_COOKIE['remember_token']) && !self::isLoggedIn()) {
            try {
                $stmt = db()->prepare("SELECT * FROM users WHERE remember_token = ? AND status = 1 LIMIT 1");
                $stmt->execute([$_COOKIE['remember_token']]);
                $user = $stmt->fetch();

                if ($user) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['logged_in'] = true;
                    return true;
                }
            } catch (PDOException $e) {
                return false;
            }
        }
        return false;
    }

    public static function isLoggedIn() {
        return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
    }

    public static function logout() {
        if (self::isLoggedIn()) {
            logActivity($_SESSION['user_id'], 'logout', 'User logged out');
        }

        $_SESSION = [];
        session_destroy();

        if (isset($_COOKIE['remember_token'])) {
            setcookie('remember_token', '', time() - 3600, '/');
        }

        return true;
    }

    public static function requireLogin() {
        if (!self::isLoggedIn()) {
            header('Location: ' . ADMIN_URL . 'index.php');
            exit;
        }
    }

    public static function requireRole($roles) {
        self::requireLogin();
        if (!in_array($_SESSION['role'], (array)$roles)) {
            header('Location: ' . ADMIN_URL . 'dashboard.php');
            exit;
        }
    }

   